# AgentFS Decision Log

**Last updated:** 2026-01-27 (Europe/Dublin)

## D-001: MVP uses Postgres + pgvector
**Decision:** Single DB in MVP.

## D-002: No WebSockets in MVP
**Decision:** Defer subscriptions.

## D-003: No Solana in MVP
**Decision:** Defer on-chain until product wedge is proven.
